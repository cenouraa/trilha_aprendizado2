var num

num=parseFloat(prompt("Digite um número: "))

if(num%2==0){
    alert("O número inserido é PAR!!!!")
}

if(num%2!=0){
    alert("O número inserido é IMPAR!!!!")
}