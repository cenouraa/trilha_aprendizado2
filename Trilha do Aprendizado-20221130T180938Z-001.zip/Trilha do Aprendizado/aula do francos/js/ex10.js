var cont, resposta

cont=0
while(cont<1){
    alert("Como irritar o usuário com while: "+cont)
    cont++
}

for(cont=0; cont<1; cont++){
    alert("Como irritar o usuário com for: "+cont)
}

do{
    resposta=prompt("Prosseguir?")
}
while(resposta=="sim")
